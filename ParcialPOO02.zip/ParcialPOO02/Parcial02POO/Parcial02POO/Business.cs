﻿namespace Parcial02POO
{
    public class Business
    {
        public string idBusiness;
        public string LocalName;
    }
}