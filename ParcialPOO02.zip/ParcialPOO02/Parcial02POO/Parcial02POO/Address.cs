﻿namespace Parcial02POO
{
    public class Address
    {
        public string UserAddress;
        public int userID;
    }
}