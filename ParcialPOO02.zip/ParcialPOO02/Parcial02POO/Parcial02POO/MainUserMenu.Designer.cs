﻿using System.ComponentModel;

namespace Parcial02POO
{
    partial class MainUserMenu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tabMenu = new System.Windows.Forms.TabControl();
            this.Order = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BusinessCmbBox = new System.Windows.Forms.ComboBox();
            this.ProductCmbBox = new System.Windows.Forms.ComboBox();
            this.OrderReadyButton = new System.Windows.Forms.Button();
            this.AddressCmbBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.DescriptionBox = new System.Windows.Forms.TextBox();
            this.Address = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CurrentAddress = new System.Windows.Forms.TextBox();
            this.UpdateAddressButton = new System.Windows.Forms.Button();
            this.NewAddressTxt = new System.Windows.Forms.TextBox();
            this.UserOrderList = new System.Windows.Forms.TabPage();
            this.Business = new System.Windows.Forms.TabPage();
            this.Users = new System.Windows.Forms.TabPage();
            this.OrderList = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabMenu.SuspendLayout();
            this.Order.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.Address.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.tabMenu, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 465F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(502, 465);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tabMenu
            // 
            this.tabMenu.Controls.Add(this.Order);
            this.tabMenu.Controls.Add(this.Address);
            this.tabMenu.Controls.Add(this.UserOrderList);
            this.tabMenu.Controls.Add(this.Business);
            this.tabMenu.Controls.Add(this.Users);
            this.tabMenu.Controls.Add(this.OrderList);
            this.tabMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMenu.Location = new System.Drawing.Point(3, 3);
            this.tabMenu.Name = "tabMenu";
            this.tabMenu.SelectedIndex = 0;
            this.tabMenu.Size = new System.Drawing.Size(496, 459);
            this.tabMenu.TabIndex = 0;
            // 
            // Order
            // 
            this.Order.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (59)))), ((int) (((byte) (35)))),
                ((int) (((byte) (95)))));
            this.Order.Controls.Add(this.tableLayoutPanel2);
            this.Order.Location = new System.Drawing.Point(4, 24);
            this.Order.Name = "Order";
            this.Order.Padding = new System.Windows.Forms.Padding(3);
            this.Order.Size = new System.Drawing.Size(488, 431);
            this.Order.TabIndex = 0;
            this.Order.Text = "Realizar Pedido";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.08299F));
            this.tableLayoutPanel2.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.91702F));
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.BusinessCmbBox, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.ProductCmbBox, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.OrderReadyButton, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.AddressCmbBox, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.DescriptionBox, 1, 2);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.70588F));
            this.tableLayoutPanel2.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.05882F));
            this.tableLayoutPanel2.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(482, 425);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular,
                System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 85);
            this.label2.TabIndex = 3;
            this.label2.Text = "Product:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular,
                System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 85);
            this.label1.TabIndex = 0;
            this.label1.Text = "Business:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BusinessCmbBox
            // 
            this.BusinessCmbBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BusinessCmbBox.FormattingEnabled = true;
            this.BusinessCmbBox.Location = new System.Drawing.Point(215, 31);
            this.BusinessCmbBox.Name = "BusinessCmbBox";
            this.BusinessCmbBox.Size = new System.Drawing.Size(196, 23);
            this.BusinessCmbBox.TabIndex = 1;
            // 
            // ProductCmbBox
            // 
            this.ProductCmbBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ProductCmbBox.FormattingEnabled = true;
            this.ProductCmbBox.Location = new System.Drawing.Point(215, 116);
            this.ProductCmbBox.Name = "ProductCmbBox";
            this.ProductCmbBox.Size = new System.Drawing.Size(196, 23);
            this.ProductCmbBox.TabIndex = 2;
            // 
            // OrderReadyButton
            // 
            this.OrderReadyButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.OrderReadyButton.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold,
                System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.OrderReadyButton.Location = new System.Drawing.Point(147, 342);
            this.OrderReadyButton.Name = "OrderReadyButton";
            this.OrderReadyButton.Size = new System.Drawing.Size(332, 80);
            this.OrderReadyButton.TabIndex = 6;
            this.OrderReadyButton.Text = "Make an order";
            this.OrderReadyButton.UseVisualStyleBackColor = true;
            // 
            // AddressCmbBox
            // 
            this.AddressCmbBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddressCmbBox.FormattingEnabled = true;
            this.AddressCmbBox.Location = new System.Drawing.Point(215, 287);
            this.AddressCmbBox.Name = "AddressCmbBox";
            this.AddressCmbBox.Size = new System.Drawing.Size(196, 23);
            this.AddressCmbBox.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular,
                System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(3, 258);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 81);
            this.label3.TabIndex = 4;
            this.label3.Text = "Address:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DescriptionBox
            // 
            this.DescriptionBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.DescriptionBox.Location = new System.Drawing.Point(197, 173);
            this.DescriptionBox.Name = "DescriptionBox";
            this.DescriptionBox.ReadOnly = true;
            this.DescriptionBox.Size = new System.Drawing.Size(231, 23);
            this.DescriptionBox.TabIndex = 7;
            // 
            // Address
            // 
            this.Address.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (59)))), ((int) (((byte) (35)))),
                ((int) (((byte) (95)))));
            this.Address.Controls.Add(this.tableLayoutPanel3);
            this.Address.Location = new System.Drawing.Point(4, 24);
            this.Address.Name = "Address";
            this.Address.Padding = new System.Windows.Forms.Padding(3);
            this.Address.Size = new System.Drawing.Size(488, 431);
            this.Address.TabIndex = 1;
            this.Address.Text = "Dirección";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.6473F));
            this.tableLayoutPanel3.ColumnStyles.Add(
                new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.3527F));
            this.tableLayoutPanel3.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.CurrentAddress, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.UpdateAddressButton, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.NewAddressTxt, 1, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.94118F));
            this.tableLayoutPanel3.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.58823F));
            this.tableLayoutPanel3.RowStyles.Add(
                new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.23529F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(482, 425);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular,
                System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 164);
            this.label5.TabIndex = 4;
            this.label5.Text = "New Address";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular,
                System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 140);
            this.label4.TabIndex = 0;
            this.label4.Text = "Old address";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CurrentAddress
            // 
            this.CurrentAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CurrentAddress.Location = new System.Drawing.Point(208, 58);
            this.CurrentAddress.Name = "CurrentAddress";
            this.CurrentAddress.ReadOnly = true;
            this.CurrentAddress.Size = new System.Drawing.Size(233, 23);
            this.CurrentAddress.TabIndex = 1;
            // 
            // UpdateAddressButton
            // 
            this.UpdateAddressButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.UpdateAddressButton.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold,
                System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.UpdateAddressButton.Location = new System.Drawing.Point(170, 307);
            this.UpdateAddressButton.Name = "UpdateAddressButton";
            this.UpdateAddressButton.Size = new System.Drawing.Size(309, 115);
            this.UpdateAddressButton.TabIndex = 2;
            this.UpdateAddressButton.Text = "Actualizar dirección";
            this.UpdateAddressButton.UseVisualStyleBackColor = true;
            // 
            // NewAddressTxt
            // 
            this.NewAddressTxt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NewAddressTxt.Location = new System.Drawing.Point(208, 210);
            this.NewAddressTxt.Name = "NewAddressTxt";
            this.NewAddressTxt.Size = new System.Drawing.Size(233, 23);
            this.NewAddressTxt.TabIndex = 3;
            // 
            // UserOrderList
            // 
            this.UserOrderList.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (59)))),
                ((int) (((byte) (35)))), ((int) (((byte) (95)))));
            this.UserOrderList.Location = new System.Drawing.Point(4, 24);
            this.UserOrderList.Name = "UserOrderList";
            this.UserOrderList.Size = new System.Drawing.Size(488, 431);
            this.UserOrderList.TabIndex = 4;
            this.UserOrderList.Text = "Lista de Pedidos";
            // 
            // Business
            // 
            this.Business.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (59)))), ((int) (((byte) (35)))),
                ((int) (((byte) (95)))));
            this.Business.Location = new System.Drawing.Point(4, 24);
            this.Business.Name = "Business";
            this.Business.Padding = new System.Windows.Forms.Padding(3);
            this.Business.Size = new System.Drawing.Size(488, 431);
            this.Business.TabIndex = 2;
            this.Business.Text = "Negocios";
            // 
            // Users
            // 
            this.Users.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (59)))), ((int) (((byte) (35)))),
                ((int) (((byte) (95)))));
            this.Users.Location = new System.Drawing.Point(4, 24);
            this.Users.Name = "Users";
            this.Users.Padding = new System.Windows.Forms.Padding(3);
            this.Users.Size = new System.Drawing.Size(488, 431);
            this.Users.TabIndex = 3;
            this.Users.Text = "Usuarios";
            // 
            // OrderList
            // 
            this.OrderList.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (59)))), ((int) (((byte) (35)))),
                ((int) (((byte) (95)))));
            this.OrderList.Location = new System.Drawing.Point(4, 24);
            this.OrderList.Name = "OrderList";
            this.OrderList.Size = new System.Drawing.Size(488, 431);
            this.OrderList.TabIndex = 5;
            this.OrderList.Text = "Pedidos";
            // 
            // MainUserMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "MainUserMenu";
            this.Size = new System.Drawing.Size(502, 465);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tabMenu.ResumeLayout(false);
            this.Order.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.Address.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TabPage UserOrderList;
        private System.Windows.Forms.TabPage OrderList;
        private System.Windows.Forms.TabPage Order;
        private System.Windows.Forms.TabPage Address;
        private System.Windows.Forms.TabPage Business;
        private System.Windows.Forms.TabPage Users;
        private System.Windows.Forms.TabControl tabMenu;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox ProductCmbBox;
        private System.Windows.Forms.ComboBox AddressCmbBox;
        private System.Windows.Forms.ComboBox BusinessCmbBox;
        private System.Windows.Forms.Button OrderReadyButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CurrentAddress;
        private System.Windows.Forms.TextBox DescriptionBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox NewAddressTxt;
        private System.Windows.Forms.Button UpdateAddressButton;
    }
}