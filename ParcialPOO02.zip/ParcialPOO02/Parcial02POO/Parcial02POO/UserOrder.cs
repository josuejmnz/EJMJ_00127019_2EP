﻿namespace Parcial02POO
{
    public class UserOrder
    {
        
    }
}